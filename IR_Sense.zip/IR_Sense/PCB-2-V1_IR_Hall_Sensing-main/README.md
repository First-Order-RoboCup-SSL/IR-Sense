# 2025Seaboat_IR_and_Hall_Sensors
### Schematics 
![image](https://github.com/user-attachments/assets/d866bb96-dc92-43af-90a1-0b8cac5010bf)
main circuit for analog hall detector

![image](https://github.com/user-attachments/assets/5927d09b-f723-43ad-9643-64edaf685241)
main circuit for IR detector

### Layout
![image](halIR_layout.png)

### PCB Preview
![image](SeaBoat_Hall&IR.jpg)


